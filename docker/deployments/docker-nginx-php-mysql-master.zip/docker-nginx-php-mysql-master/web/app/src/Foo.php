<?php

namespace App\Acme;

class Foo
{
    public function getName()
    {
        return 'Nginx PHP MySQL';
    }
}
